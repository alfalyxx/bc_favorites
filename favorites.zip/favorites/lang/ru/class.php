<?php
$MESS["ALFA_FAVORITES_USER_IS_NOT_AUTHORIZED"] = "Неавторизованный пользователь";
$MESS["ALFA_FAVORITES_INVALID_ACTION"] = "Неизвестное действие";

