<?php
$MESS["ALFA_FAVORITES_ENTITY"] = "Тип сущности";
$MESS["ALFA_FAVORITES_ENTITY_ELEMENT"] = "Элемент инфоблока";
$MESS["ALFA_FAVORITES_ENTITY_SECTION"] = "Раздел инфоблока";
$MESS["ALFA_FAVORITES_ENTITY_AUDIO"] = "Аудиофайл";
$MESS["ALFA_FAVORITES_ENTITY_VIDEO"] = "Видеофайл";
$MESS["ALFA_FAVORITES_ENTITY_OTHER"] = "Другое";
$MESS["ALFA_FAVORITES_ENTITY_ID"] = "ID сущности";

$MESS["ALFA_FAVORITES_ADD_TEXT"] = "Текст кнопки 'Добавить в избранное'";
$MESS["ALFA_FAVORITES_ADD_DEFAULT"] = "Добавить в избранное";
$MESS["ALFA_FAVORITES_REMOVE_TEXT"] = "Текст кнопки 'Удалить из избранного'";
$MESS["ALFA_FAVORITES_REMOVE_DEFAULT"] = "Удалить из избранного";
$MESS["ALFA_FAVORITES_USE_ICONS"] = "Использовать только иконки";

$MESS["ALFA_FAVORITES_ICON_TYPE"] = "Тип иконки";
$MESS["ALFA_FAVORITES_ICON_HEART"] = "Сердце ❤️";
$MESS["ALFA_FAVORITES_ICON_STAR"] = "Звезда ⭐";
$MESS["ALFA_FAVORITES_ICON_CUSTOM"] = "Своя иконка (SVG)";
$MESS["ALFA_FAVORITES_CUSTOM_SVG"] = "Ваш SVG-код";

$MESS["ALFA_FAVORITES_ICON_COLOR"] = "Цвет иконки (обычный)";
$MESS["ALFA_FAVORITES_ICON_ACTIVE_COLOR"] = "Цвет иконки (активный)";